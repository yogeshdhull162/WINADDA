# WIN ADDA — Cashfree Sandbox

Set these Supabase Edge Function secrets before using Cashfree sandbox:

- `CASHFREE_CLIENT_ID`
- `CASHFREE_CLIENT_SECRET`
- `CASHFREE_ENV=sandbox`
- `CASHFREE_API_VERSION=2025-01-01`

The secret is never placed in the browser or APK. Cashfree orders are created server-side, checkout receives only the payment session ID, payment status is checked server-side, and webhook signatures are verified before wallet credit.
