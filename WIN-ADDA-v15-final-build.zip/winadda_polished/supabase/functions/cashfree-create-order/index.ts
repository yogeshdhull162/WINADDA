import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const auth = req.headers.get("Authorization");
    if (!auth) return json({ error: "Authentication required" }, 401);
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const clientId = Deno.env.get("CASHFREE_CLIENT_ID");
    const clientSecret = Deno.env.get("CASHFREE_CLIENT_SECRET");
    const env = (Deno.env.get("CASHFREE_ENV") || "sandbox").toLowerCase();
    const apiVersion = Deno.env.get("CASHFREE_API_VERSION") || "2025-01-01";
    if (!clientId || !clientSecret) return json({ error: "Cashfree sandbox is not configured on the server yet." }, 503);
    if (env !== "sandbox") return json({ error: "This function is locked to Cashfree sandbox mode." }, 400);

    const userClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } } });
    const { data: userData, error: userError } = await userClient.auth.getUser();
    if (userError || !userData.user) return json({ error: "Invalid session" }, 401);
    const user = userData.user;

    const body = await req.json().catch(() => ({}));
    const amount = Number(body.amount);
    const phone = String(body.phone || "").replace(/\D/g, "");
    if (!Number.isFinite(amount) || amount < 10 || amount > 100000) return json({ error: "Amount must be between ₹10 and ₹100,000." }, 400);
    if (!/^\d{10}$/.test(phone)) return json({ error: "Enter a valid 10-digit mobile number." }, 400);

    const db = createClient(supabaseUrl, serviceKey);
    const { data: localOrder, error: insertError } = await db.from("payment_orders").insert({
      user_id: user.id,
      amount,
      provider: "cashfree",
      status: "created",
      payment_method: "cashfree_sandbox",
      provider_reference: `WA-${crypto.randomUUID().replaceAll("-", "")}`
    }).select("id,amount,status,provider_reference").single();
    if (insertError || !localOrder) return json({ error: insertError?.message || "Could not create payment order." }, 500);

    const cfOrderId = `wa_${localOrder.id.replaceAll("-", "")}`;
    const origin = req.headers.get("origin") || "https://winadda.app";
    const webhookUrl = `${supabaseUrl}/functions/v1/cashfree-webhook`;
    const returnUrl = `${origin.replace(/\/$/, "")}/?cashfree_order_id=${encodeURIComponent(localOrder.id)}`;
    const cfResponse = await fetch("https://sandbox.cashfree.com/pg/orders", {
      method: "POST",
      headers: {
        "x-client-id": clientId,
        "x-client-secret": clientSecret,
        "x-api-version": apiVersion,
        "Accept": "application/json",
        "Content-Type": "application/json",
        "x-idempotency-key": localOrder.id
      },
      body: JSON.stringify({
        order_amount: Number(localOrder.amount),
        order_currency: "INR",
        order_id: cfOrderId,
        customer_details: { customer_id: user.id, customer_email: user.email || "sandbox@winadda.app", customer_phone: phone },
        order_meta: { return_url: returnUrl, notify_url: webhookUrl },
        order_note: "WIN ADDA sandbox wallet deposit"
      })
    });
    const cf = await cfResponse.json().catch(() => ({}));
    if (!cfResponse.ok || !cf.payment_session_id) {
      await db.from("payment_orders").update({ status: "failed", provider_reference: cfOrderId }).eq("id", localOrder.id);
      return json({ error: cf?.message || cf?.error_description || "Cashfree sandbox order creation failed.", details: cf }, 502);
    }
    await db.from("payment_orders").update({ provider_reference: cfOrderId, payment_method: "cashfree_sandbox" }).eq("id", localOrder.id);
    return json({ local_order_id: localOrder.id, cashfree_order_id: cfOrderId, payment_session_id: cf.payment_session_id, amount: Number(localOrder.amount), environment: "sandbox" });
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : "Unexpected error" }, 500);
  }
});
