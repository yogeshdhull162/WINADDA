import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const auth = req.headers.get("Authorization"); if (!auth) return json({ error: "Authentication required" }, 401);
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const clientId = Deno.env.get("CASHFREE_CLIENT_ID"); const clientSecret = Deno.env.get("CASHFREE_CLIENT_SECRET");
    if (!clientId || !clientSecret) return json({ error: "Cashfree sandbox is not configured on the server yet." }, 503);
    const userClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: auth } } });
    const { data: ud } = await userClient.auth.getUser(); if (!ud.user) return json({ error: "Invalid session" }, 401);
    const body = await req.json().catch(() => ({})); const localId = String(body.local_order_id || "");
    if (!localId) return json({ error: "local_order_id is required" }, 400);
    const db = createClient(supabaseUrl, serviceKey);
    const { data: order, error } = await db.from("payment_orders").select("id,user_id,amount,status,provider_reference").eq("id", localId).eq("user_id", ud.user.id).single();
    if (error || !order) return json({ error: "Payment order not found" }, 404);
    if (order.status === "paid") return json({ status: "SUCCESS", credited: true, local_order_id: order.id });
    const r = await fetch(`https://sandbox.cashfree.com/pg/orders/${encodeURIComponent(order.provider_reference)}/payments`, { headers: { "x-client-id": clientId, "x-client-secret": clientSecret, "x-api-version": Deno.env.get("CASHFREE_API_VERSION") || "2025-01-01", "Accept": "application/json" } });
    const payments = await r.json().catch(() => []);
    if (!r.ok) return json({ error: "Cashfree status lookup failed", details: payments }, 502);
    const success = Array.isArray(payments) && payments.find((p: any) => p.payment_status === "SUCCESS");
    const amountMatches = success && Number(success.payment_amount) === Number(order.amount) && success.payment_currency === "INR";
    if (amountMatches) {
      const { error: creditError } = await db.rpc("cashfree_credit_payment", { p_local_order_id: order.id, p_cashfree_payment_id: String(success.cf_payment_id || ""), p_cashfree_order_id: order.provider_reference, p_amount: Number(success.payment_amount) });
      if (creditError) return json({ error: creditError.message }, 500);
      return json({ status: "SUCCESS", credited: true, local_order_id: order.id });
    }
    const pending = Array.isArray(payments) && payments.some((p: any) => p.payment_status === "PENDING");
    return json({ status: pending ? "PENDING" : "FAILED", credited: false, local_order_id: order.id });
  } catch (e) { return json({ error: e instanceof Error ? e.message : "Unexpected error" }, 500); }
});
