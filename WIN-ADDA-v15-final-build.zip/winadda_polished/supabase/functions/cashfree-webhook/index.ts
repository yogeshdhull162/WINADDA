import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

async function hmacBase64(secret: string, value: string) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(value));
  let bin = ""; for (const b of new Uint8Array(sig)) bin += String.fromCharCode(b);
  return btoa(bin);
}
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ ok: true });
  try {
    const raw = await req.text();
    const signature = req.headers.get("x-webhook-signature") || "";
    const timestamp = req.headers.get("x-webhook-timestamp") || "";
    const secret = Deno.env.get("CASHFREE_CLIENT_SECRET"); const clientId = Deno.env.get("CASHFREE_CLIENT_ID");
    if (!secret || !clientId) return json({ error: "Webhook gateway is not configured" }, 503);
    const expected = await hmacBase64(secret, timestamp + raw);
    if (!signature || !timestamp || signature !== expected) return json({ error: "Invalid webhook signature" }, 401);
    const payload = JSON.parse(raw);
    const payment = payload?.data?.payment; const cfOrderId = payload?.data?.order?.order_id;
    if (!payment || !cfOrderId) return json({ ok: true, ignored: true });
    if (payment.payment_status !== "SUCCESS") return json({ ok: true, status: payment.payment_status });
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!; const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const db = createClient(supabaseUrl, serviceKey);
    const { data: order } = await db.from("payment_orders").select("id,amount,status").eq("provider_reference", cfOrderId).maybeSingle();
    if (!order) return json({ ok: true, ignored: true });
    if (Number(payment.payment_amount) !== Number(order.amount) || payment.payment_currency !== "INR") return json({ error: "Payment amount/currency mismatch" }, 400);
    const { error } = await db.rpc("cashfree_credit_payment", { p_local_order_id: order.id, p_cashfree_payment_id: String(payment.cf_payment_id || ""), p_cashfree_order_id: cfOrderId, p_amount: Number(payment.payment_amount) });
    if (error) return json({ error: error.message }, 500);
    return json({ ok: true, credited: true });
  } catch (e) { return json({ error: e instanceof Error ? e.message : "Unexpected error" }, 500); }
});
