# WIN ADDA — Final Polish Build (V13)

Premium tournament platform UI for BGMI / Free Fire with Supabase-backed player, tournament, wallet, organizer/admin, notifications, leaderboard, UPI and sandbox payment flows.

## What changed
- Smooth-first mobile rendering: removed expensive continuous blur/pulse effects from the navigation shell.
- Faster page transitions and instant navigation scroll (no smooth-scroll jank).
- Touch feedback instead of hover transforms on phones; hover effects remain for desktop pointers.
- Reduced-motion accessibility support.
- PWA install/offline shell via `sw.js`.
- Fixed duplicate UPI UTR element IDs.
- Preserved existing Supabase and wallet logic.

## Payments
The included sandbox UI is a test simulator. It does not represent a live Cashfree transaction.
For Cashfree, production secrets must remain server-side and the payment result must be verified server-side/webhook-side before crediting wallet balance.

## Build as Android
This source can be wrapped with Capacitor/Android Studio or another WebView shell. The current environment used to prepare this package does not contain the Android SDK/Gradle build toolchain, so no APK was fabricated or falsely labeled as final.

## Cashfree Sandbox

V13 now includes a real Cashfree sandbox adapter (not a fake provider call). The client opens Cashfree Checkout in sandbox mode; order creation, payment-status checks, webhook verification and wallet credit happen server-side through Supabase Edge Functions. Add Cashfree sandbox credentials as Edge Function secrets using `CASHFREE_CLIENT_ID` and `CASHFREE_CLIENT_SECRET`. See `CASHFREE_SANDBOX_SETUP.md`.
