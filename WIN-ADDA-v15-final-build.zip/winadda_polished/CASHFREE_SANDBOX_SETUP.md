# WIN ADDA — Cashfree Sandbox Setup

The Cashfree sandbox backend is already deployed to the WIN ADDA Supabase project.

## Server secrets

In Supabase Dashboard → Project Settings → Edge Functions → Secrets, add:

- `CASHFREE_CLIENT_ID` = your Cashfree **Sandbox/Test** App ID
- `CASHFREE_CLIENT_SECRET` = your Cashfree **Sandbox/Test** Secret Key
- `CASHFREE_ENV` = `sandbox`
- `CASHFREE_API_VERSION` = `2025-01-01`

Never put the secret in `index.html`, the PWA, or the Android APK.

## Cashfree webhook

Webhook endpoint:

`https://fxqdubrrfaenpulqwyjw.supabase.co/functions/v1/cashfree-webhook`

The backend also sends this URL as `notify_url` when it creates sandbox orders.

## Flow

1. Player enters amount + mobile number.
2. `cashfree-create-order` creates the Cashfree sandbox order server-side.
3. WIN ADDA opens Cashfree sandbox checkout with only the payment session ID.
4. After checkout, WIN ADDA calls `cashfree-status`.
5. Cashfree webhook is signature-verified.
6. The server checks payment status, INR currency, and exact amount.
7. `cashfree_credit_payment` credits the WIN ADDA test wallet idempotently.

Cashfree sandbox API base: `https://sandbox.cashfree.com/pg`
